
import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import CategoryBadge from '@/components/ui/CategoryBadge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { getCourseById, getCoursesByCategory } from '@/data/coursesData';
import CourseCard from '@/components/courses/CourseCard';

const CourseDetailsPage = () => {
  const { id } = useParams<{ id: string }>();
  const course = getCourseById(id || '');
  const [activeTab, setActiveTab] = useState('overview');
  const [relatedCourses, setRelatedCourses] = useState([]);
  
  useEffect(() => {
    // Scroll to top when the page loads
    window.scrollTo(0, 0);
    
    // Set related courses based on the current course's category
    if (course) {
      const related = getCoursesByCategory(course.category)
        .filter(c => c.id !== course.id)
        .slice(0, 4);
      setRelatedCourses(related);
    }
  }, [course]);

  // If course not found, show error message
  if (!course) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <div className="flex-grow flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4">Course Not Found</h2>
            <p className="text-gray-600 mb-6">The course you're looking for doesn't exist or has been removed.</p>
            <Link to="/courses">
              <Button className="btn-primary">Browse All Courses</Button>
            </Link>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  // Format price
  const formatPrice = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount);
  };

  // Calculate discount percentage
  const discountPercentage = course.discountPrice
    ? Math.round(((course.price - course.discountPrice) / course.price) * 100)
    : 0;

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow">
        {/* Course Header */}
        <div className="bg-gradient-to-r from-brand-900 to-brand-700 text-white py-12">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row gap-8">
              {/* Course Image */}
              <div className="md:w-2/5 lg:w-1/3">
                <div className="relative rounded-xl overflow-hidden shadow-xl">
                  <img 
                    src={course.image} 
                    alt={course.title} 
                    className="w-full h-auto object-cover"
                  />
                  {course.previewVideo && (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <button 
                        className="bg-white bg-opacity-80 hover:bg-opacity-100 rounded-full p-4 transition-all transform hover:scale-105"
                        onClick={() => setActiveTab('preview')}
                      >
                        <svg className="w-10 h-10 text-brand-700" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" />
                        </svg>
                      </button>
                    </div>
                  )}
                </div>
              </div>
              
              {/* Course Info */}
              <div className="md:w-3/5 lg:w-2/3">
                <CategoryBadge category={course.category} className="mb-3" />
                <h1 className="text-3xl md:text-4xl font-bold mb-4">{course.title}</h1>
                
                <p className="text-gray-200 mb-6">{course.description}</p>
                
                <div className="flex items-center mb-4">
                  <div className="flex mr-4">
                    {[...Array(5)].map((_, i) => (
                      <svg 
                        key={i} 
                        className={`w-5 h-5 ${i < Math.floor(course.rating) ? 'text-yellow-400' : 'text-gray-300'}`} 
                        fill="currentColor" 
                        viewBox="0 0 20 20"
                      >
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                      </svg>
                    ))}
                  </div>
                  <span className="text-white">
                    {course.rating} ({course.ratingCount} ratings)
                  </span>
                </div>
                
                <div className="flex flex-wrap gap-y-4 gap-x-6 text-sm text-gray-200 mb-6">
                  <div className="flex items-center">
                    <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                    </svg>
                    <span>Instructor: <span className="font-semibold">{course.instructor}</span></span>
                  </div>
                  <div className="flex items-center">
                    <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <span>Duration: <span className="font-semibold">{course.duration}</span></span>
                  </div>
                  <div className="flex items-center">
                    <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M9 19l3 3m0 0l3-3m-3 3V10" />
                    </svg>
                    <span>Last updated: <span className="font-semibold">{course.updatedAt}</span></span>
                  </div>
                  <div className="flex items-center">
                    <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                    </svg>
                    <span>Level: <span className="font-semibold capitalize">{course.level}</span></span>
                  </div>
                </div>
                
                {/* Pricing and Enrollment Section */}
                <div className="bg-white bg-opacity-10 p-6 rounded-lg backdrop-blur-sm">
                  <div className="flex items-center mb-4">
                    {course.discountPrice ? (
                      <>
                        <span className="text-3xl font-bold text-white mr-3">{formatPrice(course.discountPrice)}</span>
                        <span className="text-xl text-gray-300 line-through mr-3">{formatPrice(course.price)}</span>
                        <span className="bg-red-600 text-white text-sm font-semibold px-2 py-1 rounded">
                          {discountPercentage}% OFF
                        </span>
                      </>
                    ) : (
                      <span className="text-3xl font-bold text-white">{formatPrice(course.price)}</span>
                    )}
                  </div>
                  
                  <div className="flex flex-col sm:flex-row gap-4">
                    <Button className="btn-primary py-6 flex-1 text-lg">
                      Enroll Now
                    </Button>
                    {course.previewVideo && (
                      <Button 
                        variant="outline" 
                        className="bg-transparent border-2 border-white text-white hover:bg-white/10 py-6 flex-1 text-lg"
                        onClick={() => setActiveTab('preview')}
                      >
                        Watch Preview
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Course Content Tabs */}
        <div className="container mx-auto px-4 py-12">
          <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid grid-cols-3 lg:grid-cols-5 mb-8">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="curriculum">Curriculum</TabsTrigger>
              <TabsTrigger value="instructor">Instructor</TabsTrigger>
              <TabsTrigger value="reviews">Reviews</TabsTrigger>
              {course.previewVideo && <TabsTrigger value="preview">Preview</TabsTrigger>}
            </TabsList>
            
            <TabsContent value="overview" className="pt-4">
              <div className="grid md:grid-cols-3 gap-8">
                <div className="md:col-span-2">
                  <h3 className="text-2xl font-bold mb-6">Course Description</h3>
                  <div className="prose max-w-none">
                    <p className="mb-4">
                      {course.description}
                    </p>
                    <p className="mb-4">
                      This comprehensive course is designed to help students master all the key concepts and skills required to excel in {course.title}. With a focus on practical examples and real-world applications, students will develop a deep understanding of the subject matter.
                    </p>
                    <h4 className="text-xl font-bold mt-8 mb-4">What You'll Learn</h4>
                    <ul className="space-y-3 mb-6">
                      {course.topics.map((topic, index) => (
                        <li key={index} className="flex items-start">
                          <svg className="w-5 h-5 text-green-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                          </svg>
                          <span>{topic}</span>
                        </li>
                      ))}
                    </ul>
                    
                    <h4 className="text-xl font-bold mt-8 mb-4">Requirements</h4>
                    <ul className="space-y-3">
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-brand-600 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <span>Basic understanding of the subject</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-brand-600 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <span>Access to a computer with internet connection</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-brand-600 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <span>Willingness to learn and practice</span>
                      </li>
                    </ul>
                  </div>
                </div>
                
                <div className="md:col-span-1">
                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h3 className="text-xl font-bold mb-4">Course Includes</h3>
                    <ul className="space-y-4">
                      <li className="flex items-center">
                        <svg className="w-5 h-5 text-brand-600 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                        </svg>
                        <span>{course.lessons} video lessons</span>
                      </li>
                      <li className="flex items-center">
                        <svg className="w-5 h-5 text-brand-600 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <span>{course.duration} of content</span>
                      </li>
                      <li className="flex items-center">
                        <svg className="w-5 h-5 text-brand-600 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
                        </svg>
                        <span>Downloadable resources</span>
                      </li>
                      <li className="flex items-center">
                        <svg className="w-5 h-5 text-brand-600 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                        </svg>
                        <span>Practice exercises</span>
                      </li>
                      <li className="flex items-center">
                        <svg className="w-5 h-5 text-brand-600 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                        </svg>
                        <span>Certificate of completion</span>
                      </li>
                      <li className="flex items-center">
                        <svg className="w-5 h-5 text-brand-600 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                        </svg>
                        <span>Email support</span>
                      </li>
                      <li className="flex items-center">
                        <svg className="w-5 h-5 text-brand-600 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                        </svg>
                        <span>Lifetime access</span>
                      </li>
                    </ul>
                    
                    <div className="mt-8">
                      <Button className="w-full btn-primary">Enroll Now</Button>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="curriculum" className="pt-4">
              <h3 className="text-2xl font-bold mb-6">Course Curriculum</h3>
              <div className="space-y-4">
                {/* Generate some dummy curriculum sections */}
                {[...Array(5)].map((_, sectionIndex) => (
                  <div key={sectionIndex} className="border rounded-lg overflow-hidden">
                    <div className="bg-gray-50 p-4 border-b">
                      <h4 className="font-bold text-lg">Section {sectionIndex + 1}: {course.topics[sectionIndex % course.topics.length]}</h4>
                      <p className="text-sm text-gray-600">4 lectures • 45min</p>
                    </div>
                    <div className="divide-y">
                      {[...Array(4)].map((_, lectureIndex) => (
                        <div key={lectureIndex} className="p-4 flex justify-between items-center">
                          <div className="flex items-center">
                            <svg className="w-5 h-5 text-gray-500 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                            <span>Lecture {lectureIndex + 1}: Introduction to {course.topics[sectionIndex % course.topics.length]}</span>
                          </div>
                          <span className="text-sm text-gray-500">{(lectureIndex + 1) * 5}:00</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="instructor" className="pt-4">
              <h3 className="text-2xl font-bold mb-6">Meet Your Instructor</h3>
              <div className="flex flex-col md:flex-row gap-8">
                <div className="md:w-1/4">
                  <img 
                    src={`https://randomuser.me/api/portraits/${course.instructor.includes('Dr.') ? 'men' : 'women'}/${parseInt(course.id) * 11 % 99}.jpg`} 
                    alt={course.instructor} 
                    className="w-48 h-48 rounded-full object-cover mx-auto md:mx-0"
                  />
                </div>
                <div className="md:w-3/4">
                  <h4 className="text-xl font-bold mb-2">{course.instructor}</h4>
                  <p className="text-gray-600 mb-4">{course.category === 'banking' ? 'Banking Expert' : course.category === 'ssc' ? 'SSC Specialist' : `${course.topics[0]} Professor`}</p>
                  <div className="flex items-center mb-4">
                    <div className="flex text-yellow-400">
                      {[...Array(5)].map((_, i) => (
                        <svg key={i} className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                        </svg>
                      ))}
                    </div>
                    <span className="ml-2 text-gray-600">4.9 Instructor Rating</span>
                  </div>
                  <div className="flex flex-wrap gap-4 text-sm text-gray-600 mb-6">
                    <span className="flex items-center">
                      <svg className="w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                      </svg>
                      24,500+ Students
                    </span>
                    <span className="flex items-center">
                      <svg className="w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                      </svg>
                      15 Courses
                    </span>
                    <span className="flex items-center">
                      <svg className="w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                      10+ Years Experience
                    </span>
                  </div>
                  <p className="text-gray-700 mb-4">
                    {course.instructor} is a passionate educator with over 10 years of experience in teaching {course.topics.join(', ')}. 
                    With a background in both academia and industry, they bring a unique perspective to their courses, combining 
                    theoretical knowledge with practical applications.
                  </p>
                  <p className="text-gray-700">
                    Having helped thousands of students succeed in their exams and career paths, 
                    {course.instructor} is known for their ability to break down complex concepts into easy-to-understand 
                    lessons. Their teaching methodology focuses on building a strong foundation and developing 
                    problem-solving skills that students can apply in real-life situations.
                  </p>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="reviews" className="pt-4">
              <div className="flex flex-col md:flex-row gap-8">
                <div className="md:w-1/3">
                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h3 className="text-2xl font-bold mb-2">Student Feedback</h3>
                    <div className="flex items-center mb-4">
                      <div className="mr-2 text-3xl font-bold">{course.rating}</div>
                      <div>
                        <div className="flex text-yellow-400">
                          {[...Array(5)].map((_, i) => (
                            <svg 
                              key={i} 
                              className={`w-5 h-5 ${i < Math.floor(course.rating) ? 'text-yellow-400' : 'text-gray-300'}`}
                              fill="currentColor" 
                              viewBox="0 0 20 20"
                            >
                              <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                            </svg>
                          ))}
                        </div>
                        <div className="text-sm text-gray-600">Course Rating</div>
                      </div>
                    </div>
                    
                    {/* Rating Distribution */}
                    <div className="space-y-2">
                      {[5, 4, 3, 2, 1].map((star) => {
                        const percentage = star === 5 ? 78 : 
                                          star === 4 ? 15 : 
                                          star === 3 ? 5 : 
                                          star === 2 ? 1 : 1;
                        return (
                          <div key={star} className="flex items-center">
                            <div className="w-12 text-sm text-gray-600 flex items-center">
                              <span>{star}</span>
                              <svg className="w-4 h-4 text-yellow-400 ml-1" fill="currentColor" viewBox="0 0 20 20">
                                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                              </svg>
                            </div>
                            <div className="flex-1 ml-4">
                              <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                                <div 
                                  className="h-full bg-yellow-400" 
                                  style={{ width: `${percentage}%` }}
                                ></div>
                              </div>
                            </div>
                            <div className="w-12 text-right text-sm text-gray-600">{percentage}%</div>
                          </div>
                        );
                      })}
                    </div>
                    
                    <div className="mt-6">
                      <p className="text-center text-gray-700">
                        {course.ratingCount} ratings
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="md:w-2/3">
                  <h3 className="text-2xl font-bold mb-6">Reviews</h3>
                  
                  <div className="space-y-6">
                    {/* Generate some dummy reviews */}
                    {[...Array(3)].map((_, index) => {
                      const rating = 5 - (index % 2);
                      return (
                        <div key={index} className="border-b pb-6 mb-6 last:border-b-0">
                          <div className="flex items-start">
                            <img 
                              src={`https://randomuser.me/api/portraits/${index % 2 ? 'women' : 'men'}/${(parseInt(course.id) + index * 13) % 99}.jpg`} 
                              alt="Student" 
                              className="w-12 h-12 rounded-full mr-4"
                            />
                            <div className="flex-1">
                              <div className="flex items-center justify-between">
                                <h4 className="font-bold">
                                  {index === 0 ? 'Amit Kumar' : index === 1 ? 'Priya Sharma' : 'Vikram Singh'}
                                </h4>
                                <span className="text-sm text-gray-500">
                                  {index === 0 ? '2 weeks ago' : index === 1 ? '1 month ago' : '2 months ago'}
                                </span>
                              </div>
                              <div className="flex text-yellow-400 my-1">
                                {[...Array(5)].map((_, i) => (
                                  <svg 
                                    key={i} 
                                    className={`w-4 h-4 ${i < rating ? 'text-yellow-400' : 'text-gray-300'}`}
                                    fill="currentColor" 
                                    viewBox="0 0 20 20"
                                  >
                                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                  </svg>
                                ))}
                              </div>
                              <p className="text-gray-700 mt-2">
                                {index === 0 ? 
                                  `This course exceeded my expectations! The instructor explains complex ${course.topics[0]} concepts in a very easy-to-understand manner. The practice problems were challenging but helped me grasp the concepts thoroughly. Highly recommended!` : 
                                 index === 1 ?
                                  `Great course overall, but some sections felt a bit rushed. The instructor is knowledgeable and responsive to questions. The downloadable resources are very helpful for revision.` :
                                  `One of the best courses I've taken on this platform. The instructor's teaching style is engaging and the course content is comprehensive. I've seen significant improvement in my understanding of ${course.topics[1]}.`
                                }
                              </p>
                              {index === 0 && (
                                <div className="mt-3 flex items-center text-sm text-gray-500">
                                  <span className="mr-4">Was this review helpful?</span>
                                  <button className="flex items-center mr-4 hover:text-brand-600">
                                    <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 10h4.764a2 2 0 011.789 2.894l-3.5 7A2 2 0 0115.263 21h-4.017c-.163 0-.326-.02-.485-.06L7 20m7-10V5a2 2 0 00-2-2h-.095c-.5 0-.905.405-.905.905 0 .714-.211 1.412-.608 2.006L7 11v9m7-10h-2M7 20H5a2 2 0 01-2-2v-6a2 2 0 012-2h2.5" />
                                    </svg>
                                    Yes (15)
                                  </button>
                                  <button className="flex items-center hover:text-brand-600">
                                    <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 14H5.236a2 2 0 01-1.789-2.894l3.5-7A2 2 0 018.736 3h4.018a2 2 0 01.485.06l3.76.94m-7 10v5a2 2 0 002 2h.095c.5 0 .905-.405.905-.905 0-.714.211-1.412.608-2.006L17 13V4m-7 10h2" />
                                    </svg>
                                    No (2)
                                  </button>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                    
                    <div className="text-center">
                      <Button variant="outline" className="border-brand-600 text-brand-600 hover:bg-brand-50">
                        Load More Reviews
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>
            
            {course.previewVideo && (
              <TabsContent value="preview" className="pt-4">
                <h3 className="text-2xl font-bold mb-6">Course Preview</h3>
                <div className="aspect-w-16 aspect-h-9">
                  <iframe 
                    src={course.previewVideo} 
                    title="Course Preview"
                    className="w-full h-[500px] rounded-xl"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                    allowFullScreen
                  ></iframe>
                </div>
                <div className="mt-6 text-center">
                  <p className="text-gray-700 mb-4">
                    Enjoyed the preview? Enroll now to access the full course content!
                  </p>
                  <Button className="btn-primary">Enroll Now</Button>
                </div>
              </TabsContent>
            )}
          </Tabs>
        </div>
        
        {/* Related Courses */}
        {relatedCourses.length > 0 && (
          <section className="bg-gray-50 py-12">
            <div className="container mx-auto px-4">
              <h2 className="text-2xl font-bold mb-8">Related Courses</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {relatedCourses.map(relatedCourse => (
                  <CourseCard key={relatedCourse.id} course={relatedCourse} />
                ))}
              </div>
            </div>
          </section>
        )}
      </main>
      
      <Footer />
    </div>
  );
};

export default CourseDetailsPage;

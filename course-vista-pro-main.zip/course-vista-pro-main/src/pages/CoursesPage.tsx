
import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import CourseCard from '@/components/courses/CourseCard';
import CategoryBadge from '@/components/ui/CategoryBadge';
import { courses } from '@/data/coursesData';

const CoursesPage = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const categoryParam = searchParams.get('category');
  const [filteredCourses, setFilteredCourses] = useState(courses);
  const [activeCategory, setActiveCategory] = useState<string | null>(categoryParam);
  const [searchQuery, setSearchQuery] = useState('');
  const [priceFilter, setPriceFilter] = useState('all');
  const [levelFilter, setLevelFilter] = useState('all');
  
  // Define available categories
  const categories = [
    { id: 'class-1-5', name: 'Classes 1-5' },
    { id: 'class-6-10', name: 'Classes 6-10' },
    { id: 'class-11-12', name: 'Classes 11-12' },
    { id: 'ssc', name: 'SSC Exams' },
    { id: 'banking', name: 'Banking Exams' },
    { id: 'railway', name: 'Railway Exams' },
    { id: 'bpsc', name: 'BPSC' },
    { id: 'upsc', name: 'UPSC' }
  ];
  
  // Filter courses based on search query, category, price, and level
  useEffect(() => {
    let result = courses;
    
    if (activeCategory) {
      result = result.filter(course => course.category === activeCategory);
    }
    
    if (searchQuery.trim() !== '') {
      const query = searchQuery.toLowerCase();
      result = result.filter(course => 
        course.title.toLowerCase().includes(query) || 
        course.description.toLowerCase().includes(query) ||
        course.instructor.toLowerCase().includes(query)
      );
    }
    
    if (priceFilter !== 'all') {
      if (priceFilter === 'free') {
        result = result.filter(course => course.price === 0);
      } else if (priceFilter === 'paid') {
        result = result.filter(course => course.price > 0);
      } else if (priceFilter === 'under-1000') {
        result = result.filter(course => course.discountPrice ? course.discountPrice < 1000 : course.price < 1000);
      } else if (priceFilter === '1000-3000') {
        result = result.filter(course => {
          const effectivePrice = course.discountPrice || course.price;
          return effectivePrice >= 1000 && effectivePrice <= 3000;
        });
      } else if (priceFilter === 'above-3000') {
        result = result.filter(course => {
          const effectivePrice = course.discountPrice || course.price;
          return effectivePrice > 3000;
        });
      }
    }
    
    if (levelFilter !== 'all') {
      result = result.filter(course => course.level === levelFilter);
    }
    
    setFilteredCourses(result);
  }, [activeCategory, searchQuery, priceFilter, levelFilter]);
  
  // Update URL when category changes
  useEffect(() => {
    if (activeCategory) {
      searchParams.set('category', activeCategory);
    } else {
      searchParams.delete('category');
    }
    setSearchParams(searchParams);
  }, [activeCategory, searchParams, setSearchParams]);
  
  // Set active category from URL parameter on load
  useEffect(() => {
    if (categoryParam) {
      setActiveCategory(categoryParam);
    }
  }, [categoryParam]);
  
  const handleCategoryChange = (categoryId: string | null) => {
    setActiveCategory(categoryId);
  };
  
  const handleSearchChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(event.target.value);
  };
  
  const handlePriceFilterChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    setPriceFilter(event.target.value);
  };
  
  const handleLevelFilterChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    setLevelFilter(event.target.value);
  };
  
  const clearFilters = () => {
    setActiveCategory(null);
    setSearchQuery('');
    setPriceFilter('all');
    setLevelFilter('all');
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow">
        {/* Hero Section */}
        <div className="bg-gradient-to-r from-brand-900 to-brand-700 text-white py-12">
          <div className="container mx-auto px-4">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Explore Our Courses</h1>
            <p className="text-xl text-gray-200 max-w-3xl">
              Browse our extensive collection of courses designed to help you succeed in your academic and professional pursuits.
            </p>
          </div>
        </div>
        
        {/* Search and Filter Section */}
        <div className="border-b bg-gray-50">
          <div className="container mx-auto px-4 py-6">
            <div className="flex flex-wrap items-center gap-4">
              {/* Search Input */}
              <div className="w-full md:w-auto md:flex-1">
                <input
                  type="text"
                  placeholder="Search courses..."
                  value={searchQuery}
                  onChange={handleSearchChange}
                  className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-brand-500"
                />
              </div>
              
              {/* Price Filter */}
              <div className="w-full sm:w-auto">
                <select
                  value={priceFilter}
                  onChange={handlePriceFilterChange}
                  className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-brand-500 bg-white"
                >
                  <option value="all">Price: All</option>
                  <option value="free">Free</option>
                  <option value="paid">Paid</option>
                  <option value="under-1000">Under ₹1,000</option>
                  <option value="1000-3000">₹1,000 - ₹3,000</option>
                  <option value="above-3000">Above ₹3,000</option>
                </select>
              </div>
              
              {/* Level Filter */}
              <div className="w-full sm:w-auto">
                <select
                  value={levelFilter}
                  onChange={handleLevelFilterChange}
                  className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-brand-500 bg-white"
                >
                  <option value="all">Level: All</option>
                  <option value="beginner">Beginner</option>
                  <option value="intermediate">Intermediate</option>
                  <option value="advanced">Advanced</option>
                </select>
              </div>
              
              {/* Clear Filters Button */}
              <button
                onClick={clearFilters}
                className="px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-100 transition-colors text-gray-700 w-full sm:w-auto"
              >
                Clear Filters
              </button>
            </div>
            
            {/* Categories */}
            <div className="mt-4 flex flex-wrap gap-2">
              <button
                onClick={() => handleCategoryChange(null)}
                className={`px-3 py-1 rounded-full text-sm font-medium ${
                  activeCategory === null 
                    ? 'bg-brand-600 text-white' 
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                All Courses
              </button>
              {categories.map(category => (
                <button
                  key={category.id}
                  onClick={() => handleCategoryChange(category.id)}
                  className={`px-3 py-1 rounded-full text-sm font-medium ${
                    activeCategory === category.id 
                      ? 'bg-brand-600 text-white' 
                      : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                  }`}
                >
                  {category.name}
                </button>
              ))}
            </div>
          </div>
        </div>
        
        {/* Courses Grid */}
        <div className="container mx-auto px-4 py-12">
          {/* Results Count */}
          <div className="mb-8">
            <h2 className="text-2xl font-bold">
              {filteredCourses.length} {filteredCourses.length === 1 ? 'Course' : 'Courses'} 
              {activeCategory && ` in ${categories.find(c => c.id === activeCategory)?.name}`}
            </h2>
            {(activeCategory || searchQuery || priceFilter !== 'all' || levelFilter !== 'all') && (
              <div className="mt-2 flex flex-wrap gap-2">
                {activeCategory && (
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-brand-100 text-brand-800">
                    Category: {categories.find(c => c.id === activeCategory)?.name}
                    <button 
                      className="ml-1 text-brand-500 hover:text-brand-700"
                      onClick={() => setActiveCategory(null)}
                    >
                      ✕
                    </button>
                  </span>
                )}
                
                {searchQuery && (
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                    Search: {searchQuery}
                    <button 
                      className="ml-1 text-blue-500 hover:text-blue-700"
                      onClick={() => setSearchQuery('')}
                    >
                      ✕
                    </button>
                  </span>
                )}
                
                {priceFilter !== 'all' && (
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                    Price: {priceFilter === 'free' ? 'Free' : 
                            priceFilter === 'paid' ? 'Paid' :
                            priceFilter === 'under-1000' ? 'Under ₹1,000' :
                            priceFilter === '1000-3000' ? '₹1,000 - ₹3,000' : 
                            'Above ₹3,000'}
                    <button 
                      className="ml-1 text-green-500 hover:text-green-700"
                      onClick={() => setPriceFilter('all')}
                    >
                      ✕
                    </button>
                  </span>
                )}
                
                {levelFilter !== 'all' && (
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                    Level: {levelFilter.charAt(0).toUpperCase() + levelFilter.slice(1)}
                    <button 
                      className="ml-1 text-purple-500 hover:text-purple-700"
                      onClick={() => setLevelFilter('all')}
                    >
                      ✕
                    </button>
                  </span>
                )}
              </div>
            )}
          </div>
          
          {filteredCourses.length === 0 ? (
            <div className="text-center py-16">
              <svg className="w-16 h-16 text-gray-400 mx-auto mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <h3 className="text-xl font-bold text-gray-700 mb-1">No courses found</h3>
              <p className="text-gray-500 mb-4">Try adjusting your search or filter criteria</p>
              <button 
                onClick={clearFilters} 
                className="btn-primary"
              >
                Clear All Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredCourses.map(course => (
                <CourseCard key={course.id} course={course} />
              ))}
            </div>
          )}
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default CoursesPage;

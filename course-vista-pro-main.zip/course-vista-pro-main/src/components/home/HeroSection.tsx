
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';

const HeroSection = () => {
  return (
    <div className="relative bg-gradient-to-br from-brand-900 via-brand-800 to-brand-700 text-white">
      {/* Decorative Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 rounded-full bg-brand-600 opacity-20 blur-3xl"></div>
        <div className="absolute -bottom-20 -left-20 w-60 h-60 rounded-full bg-accent2-500 opacity-20 blur-3xl"></div>
      </div>
      
      <div className="container mx-auto px-4 py-16 md:py-24 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="text-center md:text-left">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
              Unlock Your <span className="text-accent2-400">Academic Potential</span>
            </h1>
            <p className="text-lg md:text-xl text-gray-200 mb-8 leading-relaxed">
              Your gateway to comprehensive learning for school curriculum and competitive exams. Quality education at your fingertips.
            </p>
            <div className="flex flex-col sm:flex-row justify-center md:justify-start space-y-4 sm:space-y-0 sm:space-x-4">
              <Link to="/courses">
                <Button className="btn-secondary text-lg py-6 px-8 w-full sm:w-auto">Explore Courses</Button>
              </Link>
              <Link to="/signup">
                <Button variant="outline" className="bg-transparent border-2 border-white text-white hover:bg-white/10 text-lg py-6 px-8 w-full sm:w-auto">Get Started Free</Button>
              </Link>
            </div>
          </div>
          
          <div className="hidden md:block">
            <div className="relative">
              <div className="absolute -top-6 -left-6 w-full h-full bg-accent2-500 rounded-xl"></div>
              <img 
                src="https://images.unsplash.com/photo-1516321497487-e288fb19713f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1740&q=80" 
                alt="Students learning"
                className="w-full h-auto rounded-xl shadow-xl relative z-10"
              />
              <div className="absolute -right-4 -bottom-4 bg-white p-4 rounded-lg shadow-xl">
                <div className="flex items-center space-x-2">
                  <div className="flex -space-x-2">
                    <img className="w-8 h-8 rounded-full border-2 border-white" src="https://randomuser.me/api/portraits/women/79.jpg" alt="User" />
                    <img className="w-8 h-8 rounded-full border-2 border-white" src="https://randomuser.me/api/portraits/men/10.jpg" alt="User" />
                    <img className="w-8 h-8 rounded-full border-2 border-white" src="https://randomuser.me/api/portraits/women/21.jpg" alt="User" />
                  </div>
                  <div className="text-sm text-gray-800">
                    <p className="font-bold">2000+ Students</p>
                    <p className="text-xs text-gray-500">Already enrolled</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Stats Section */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8 mt-16 text-center">
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
            <div className="text-3xl md:text-4xl font-bold text-white mb-1">200+</div>
            <div className="text-gray-300">Quality Courses</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
            <div className="text-3xl md:text-4xl font-bold text-white mb-1">50+</div>
            <div className="text-gray-300">Expert Instructors</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
            <div className="text-3xl md:text-4xl font-bold text-white mb-1">10K+</div>
            <div className="text-gray-300">Happy Students</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
            <div className="text-3xl md:text-4xl font-bold text-white mb-1">95%</div>
            <div className="text-gray-300">Success Rate</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HeroSection;


import { useState } from 'react';
import { Link } from 'react-router-dom';
import CourseCard from '@/components/courses/CourseCard';
import { getFeaturedCourses } from '@/data/coursesData';

const FeaturedCourses = () => {
  const featuredCourses = getFeaturedCourses();
  const [visibleCourses, setVisibleCourses] = useState(4);
  
  const showMoreCourses = () => {
    setVisibleCourses(prev => Math.min(prev + 4, featuredCourses.length));
  };
  
  const hasMoreCourses = visibleCourses < featuredCourses.length;

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center mb-12">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Featured Courses</h2>
            <p className="text-gray-600 max-w-2xl">
              Explore our handpicked selection of top-rated courses designed to help you excel in academics and competitive exams.
            </p>
          </div>
          <Link 
            to="/courses" 
            className="mt-6 md:mt-0 btn-outline"
          >
            View All Courses
          </Link>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredCourses.slice(0, visibleCourses).map((course) => (
            <CourseCard key={course.id} course={course} featured={true} />
          ))}
        </div>
        
        {hasMoreCourses && (
          <div className="flex justify-center mt-12">
            <button 
              className="btn-outline"
              onClick={showMoreCourses}
            >
              Load More Courses
            </button>
          </div>
        )}
      </div>
    </section>
  );
};

export default FeaturedCourses;

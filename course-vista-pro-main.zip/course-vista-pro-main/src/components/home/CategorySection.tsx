
import { Link } from 'react-router-dom';

const categories = [
  {
    id: 'class-1-5',
    name: 'Classes 1-5',
    icon: '📚',
    description: 'Foundation courses for primary education',
    courses: 24,
    color: 'bg-blue-100 border-blue-300 text-blue-800'
  },
  {
    id: 'class-6-10',
    name: 'Classes 6-10',
    icon: '🧪',
    description: 'Middle and high school curriculum',
    courses: 36,
    color: 'bg-green-100 border-green-300 text-green-800'
  },
  {
    id: 'class-11-12',
    name: 'Classes 11-12',
    icon: '🔬',
    description: 'Senior secondary education & board exams',
    courses: 28,
    color: 'bg-purple-100 border-purple-300 text-purple-800'
  },
  {
    id: 'ssc',
    name: 'SSC Exams',
    icon: '📝',
    description: 'Staff Selection Commission exam prep',
    courses: 15,
    color: 'bg-red-100 border-red-300 text-red-800'
  },
  {
    id: 'banking',
    name: 'Banking Exams',
    icon: '🏦',
    description: 'IBPS, SBI, RBI exam preparation',
    courses: 18,
    color: 'bg-yellow-100 border-yellow-300 text-yellow-800'
  },
  {
    id: 'railway',
    name: 'Railway Exams',
    icon: '🚆',
    description: 'RRB, RRC exam preparation',
    courses: 12,
    color: 'bg-orange-100 border-orange-300 text-orange-800'
  },
  {
    id: 'bpsc',
    name: 'BPSC',
    icon: '⚖️',
    description: 'Bihar Public Service Commission prep',
    courses: 8,
    color: 'bg-pink-100 border-pink-300 text-pink-800'
  },
  {
    id: 'upsc',
    name: 'UPSC',
    icon: '🏛️',
    description: 'Civil Services examination preparation',
    courses: 10,
    color: 'bg-indigo-100 border-indigo-300 text-indigo-800'
  }
];

const CategorySection = () => {
  return (
    <section className="py-16">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-4">Explore by Category</h2>
        <p className="text-gray-600 text-center max-w-3xl mx-auto mb-12">
          Find the perfect course for your educational needs, from school curriculum to competitive exam preparation.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {categories.map((category) => (
            <Link 
              key={category.id}
              to={`/courses?category=${category.id}`}
              className={`group border-2 ${category.color} rounded-xl p-6 transition-all duration-300 hover:shadow-lg hover:-translate-y-1`}
            >
              <div className="flex items-center justify-between mb-4">
                <span className="text-4xl" role="img" aria-label={category.name}>
                  {category.icon}
                </span>
                <span className="text-sm font-medium rounded-full px-3 py-1 bg-white bg-opacity-60">
                  {category.courses} Courses
                </span>
              </div>
              <h3 className="font-bold text-xl mb-2">{category.name}</h3>
              <p className="text-gray-600 text-sm mb-4">{category.description}</p>
              <div className="flex items-center font-medium group-hover:text-brand-700">
                Browse Courses
                <svg className="w-4 h-4 ml-2 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                </svg>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CategorySection;


import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Search, Menu, X } from 'lucide-react';

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2">
            <div className="h-10 w-10 rounded-full bg-brand-600 flex items-center justify-center">
              <span className="text-white font-bold text-xl">C</span>
            </div>
            <span className="font-sans font-bold text-2xl text-gray-800">CourseVistaPro</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <Link to="/" className="font-medium text-gray-700 hover:text-brand-600">Home</Link>
            <Link to="/courses" className="font-medium text-gray-700 hover:text-brand-600">All Courses</Link>
            <div className="relative group">
              <button className="font-medium text-gray-700 hover:text-brand-600 flex items-center">
                Categories 
                <svg className="w-5 h-5 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path>
                </svg>
              </button>
              <div className="absolute left-0 mt-2 w-48 bg-white rounded-md shadow-lg py-2 z-10 hidden group-hover:block">
                <Link to="/courses?category=class-1-5" className="block px-4 py-2 text-sm text-gray-700 hover:bg-brand-100">Classes 1-5</Link>
                <Link to="/courses?category=class-6-10" className="block px-4 py-2 text-sm text-gray-700 hover:bg-brand-100">Classes 6-10</Link>
                <Link to="/courses?category=class-11-12" className="block px-4 py-2 text-sm text-gray-700 hover:bg-brand-100">Classes 11-12</Link>
                <Link to="/courses?category=ssc" className="block px-4 py-2 text-sm text-gray-700 hover:bg-brand-100">SSC Exams</Link>
                <Link to="/courses?category=banking" className="block px-4 py-2 text-sm text-gray-700 hover:bg-brand-100">Banking Exams</Link>
                <Link to="/courses?category=railway" className="block px-4 py-2 text-sm text-gray-700 hover:bg-brand-100">Railway Exams</Link>
                <Link to="/courses?category=bpsc" className="block px-4 py-2 text-sm text-gray-700 hover:bg-brand-100">BPSC</Link>
              </div>
            </div>
            <Link to="/about" className="font-medium text-gray-700 hover:text-brand-600">About Us</Link>
          </nav>

          {/* Search and Auth Buttons - Desktop */}
          <div className="hidden md:flex items-center space-x-4">
            <div className="relative">
              <input
                type="text"
                placeholder="Search courses..."
                className="pl-10 pr-4 py-2 border rounded-full text-sm w-48 focus:outline-none focus:ring-1 focus:ring-brand-600 focus:border-brand-600"
              />
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-500" />
            </div>
            <Link to="/login">
              <Button variant="outline" className="border-brand-600 text-brand-600 hover:bg-brand-50">Login</Button>
            </Link>
            <Link to="/signup">
              <Button className="bg-brand-600 text-white hover:bg-brand-700">Sign Up</Button>
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button className="md:hidden" onClick={toggleMenu}>
            {isMenuOpen ? (
              <X className="h-6 w-6 text-gray-800" />
            ) : (
              <Menu className="h-6 w-6 text-gray-800" />
            )}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="mt-4 md:hidden">
            <div className="flex flex-col space-y-4 pb-4">
              <Link 
                to="/" 
                className="font-medium text-gray-800 hover:text-brand-600"
                onClick={toggleMenu}
              >
                Home
              </Link>
              <Link 
                to="/courses" 
                className="font-medium text-gray-800 hover:text-brand-600"
                onClick={toggleMenu}
              >
                All Courses
              </Link>
              <details className="group">
                <summary className="font-medium text-gray-800 hover:text-brand-600 list-none flex justify-between cursor-pointer">
                  Categories
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path>
                  </svg>
                </summary>
                <div className="mt-2 ml-4 flex flex-col space-y-2">
                  <Link to="/courses?category=class-1-5" className="text-gray-600 hover:text-brand-600" onClick={toggleMenu}>Classes 1-5</Link>
                  <Link to="/courses?category=class-6-10" className="text-gray-600 hover:text-brand-600" onClick={toggleMenu}>Classes 6-10</Link>
                  <Link to="/courses?category=class-11-12" className="text-gray-600 hover:text-brand-600" onClick={toggleMenu}>Classes 11-12</Link>
                  <Link to="/courses?category=ssc" className="text-gray-600 hover:text-brand-600" onClick={toggleMenu}>SSC Exams</Link>
                  <Link to="/courses?category=banking" className="text-gray-600 hover:text-brand-600" onClick={toggleMenu}>Banking Exams</Link>
                  <Link to="/courses?category=railway" className="text-gray-600 hover:text-brand-600" onClick={toggleMenu}>Railway Exams</Link>
                  <Link to="/courses?category=bpsc" className="text-gray-600 hover:text-brand-600" onClick={toggleMenu}>BPSC</Link>
                </div>
              </details>
              <Link 
                to="/about" 
                className="font-medium text-gray-800 hover:text-brand-600"
                onClick={toggleMenu}
              >
                About Us
              </Link>
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search courses..."
                  className="w-full pl-10 pr-4 py-2 border rounded-full text-sm focus:outline-none focus:ring-1 focus:ring-brand-600 focus:border-brand-600"
                />
                <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-500" />
              </div>
              <div className="flex space-x-2 pt-2">
                <Link to="/login" className="w-1/2" onClick={toggleMenu}>
                  <Button 
                    variant="outline" 
                    className="w-full border-brand-600 text-brand-600 hover:bg-brand-50"
                  >
                    Login
                  </Button>
                </Link>
                <Link to="/signup" className="w-1/2" onClick={toggleMenu}>
                  <Button 
                    className="w-full bg-brand-600 text-white hover:bg-brand-700"
                  >
                    Sign Up
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Navbar;

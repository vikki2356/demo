
import { Link } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import CategoryBadge from '@/components/ui/CategoryBadge';
import { Course } from '@/data/coursesData';

interface CourseCardProps {
  course: Course;
  featured?: boolean;
}

const CourseCard = ({ course, featured = false }: CourseCardProps) => {
  const {
    id,
    title,
    instructor,
    category,
    rating,
    ratingCount,
    price,
    discountPrice,
    image,
    lessons,
    students,
    level
  } = course;

  // Function to display formatted price
  const formatPrice = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount);
  };

  // Calculate discount percentage
  const discountPercentage = discountPrice
    ? Math.round(((price - discountPrice) / price) * 100)
    : 0;

  return (
    <Link to={`/course/${id}`}>
      <Card className={`h-full overflow-hidden card-hover ${featured ? 'shadow-lg border-blue-200' : ''}`}>
        <div className="relative">
          <img 
            src={image} 
            alt={title} 
            className="w-full h-48 object-cover"
          />
          {discountPrice && (
            <div className="absolute top-3 right-3 bg-red-600 text-white text-xs font-bold px-2 py-1 rounded">
              {discountPercentage}% OFF
            </div>
          )}
        </div>
        
        <CardContent className="p-5">
          <div className="flex justify-between items-start mb-3">
            <CategoryBadge category={category} />
            <span className="text-xs font-medium px-2 py-1 bg-gray-100 rounded-full capitalize">
              {level}
            </span>
          </div>
          
          <h3 className="font-bold text-lg mb-2 line-clamp-2" title={title}>
            {title}
          </h3>
          
          <p className="text-gray-600 text-sm mb-3">By {instructor}</p>
          
          <div className="flex items-center space-x-1 mb-3">
            <div className="flex">
              {[...Array(5)].map((_, i) => (
                <svg 
                  key={i} 
                  className={`w-4 h-4 ${i < Math.floor(rating) ? 'text-yellow-400' : 'text-gray-300'}`} 
                  fill="currentColor" 
                  viewBox="0 0 20 20"
                >
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                </svg>
              ))}
            </div>
            <span className="text-sm font-medium text-gray-700">
              {rating} ({ratingCount})
            </span>
          </div>
          
          <div className="flex items-center justify-between text-sm text-gray-600 mb-4">
            <div className="flex items-center">
              <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
              </svg>
              {lessons} Lessons
            </div>
            <div className="flex items-center">
              <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
              </svg>
              {students.toLocaleString()} Students
            </div>
          </div>
          
          <div className="border-t pt-4 flex items-center justify-between">
            <div>
              {discountPrice ? (
                <div className="flex items-center">
                  <span className="font-bold text-lg text-brand-700">{formatPrice(discountPrice)}</span>
                  <span className="text-sm text-gray-500 line-through ml-2">{formatPrice(price)}</span>
                </div>
              ) : (
                <span className="font-bold text-lg text-brand-700">{formatPrice(price)}</span>
              )}
            </div>
            <button className="btn-primary py-1.5 px-3 text-sm">View Details</button>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
};

export default CourseCard;

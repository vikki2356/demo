
import { cn } from "@/lib/utils";

interface CategoryBadgeProps {
  category: string;
  className?: string;
}

const getCategoryColor = (category: string): string => {
  const categoryMap: Record<string, string> = {
    'class-1-5': 'bg-blue-100 text-blue-800',
    'class-6-10': 'bg-green-100 text-green-800',
    'class-11-12': 'bg-purple-100 text-purple-800',
    'ssc': 'bg-red-100 text-red-800',
    'banking': 'bg-yellow-100 text-yellow-800',
    'railway': 'bg-orange-100 text-orange-800',
    'bpsc': 'bg-pink-100 text-pink-800',
    'upsc': 'bg-indigo-100 text-indigo-800',
    'default': 'bg-gray-100 text-gray-800'
  };
  
  return categoryMap[category] || categoryMap['default'];
};

const getCategoryLabel = (category: string): string => {
  const categoryLabels: Record<string, string> = {
    'class-1-5': 'Classes 1-5',
    'class-6-10': 'Classes 6-10',
    'class-11-12': 'Classes 11-12',
    'ssc': 'SSC Exams',
    'banking': 'Banking Exams',
    'railway': 'Railway Exams',
    'bpsc': 'BPSC',
    'upsc': 'UPSC'
  };
  
  return categoryLabels[category] || category;
};

const CategoryBadge = ({ category, className }: CategoryBadgeProps) => {
  const categoryColor = getCategoryColor(category);
  const categoryLabel = getCategoryLabel(category);
  
  return (
    <span className={cn(
      "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium", 
      categoryColor,
      className
    )}>
      {categoryLabel}
    </span>
  );
};

export default CategoryBadge;

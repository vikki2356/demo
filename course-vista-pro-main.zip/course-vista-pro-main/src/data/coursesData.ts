
export interface Course {
  id: string;
  title: string;
  description: string;
  instructor: string;
  category: string;
  level: 'beginner' | 'intermediate' | 'advanced';
  duration: string;
  rating: number;
  ratingCount: number;
  price: number;
  discountPrice?: number;
  image: string;
  featured: boolean;
  popular: boolean;
  lessons: number;
  students: number;
  updatedAt: string;
  topics: string[];
  previewVideo?: string;
}

export const courses: Course[] = [
  {
    id: '1',
    title: 'Complete Mathematics for Class 10 CBSE',
    description: 'Master all math concepts for Class 10 CBSE exams with comprehensive lessons, practice problems, and mock tests.',
    instructor: 'Dr. Anjali Sharma',
    category: 'class-6-10',
    level: 'intermediate',
    duration: '40 hours',
    rating: 4.8,
    ratingCount: 1240,
    price: 2499,
    discountPrice: 1999,
    image: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500&q=80',
    featured: true,
    popular: true,
    lessons: 45,
    students: 3200,
    updatedAt: '2024-03-15',
    topics: ['Algebra', 'Geometry', 'Trigonometry', 'Statistics', 'Probability'],
    previewVideo: 'https://www.youtube.com/embed/C8JBHxckkAY'
  },
  {
    id: '2',
    title: 'SSC CGL Complete Preparation',
    description: 'Comprehensive preparation course for SSC CGL exam covering all sections with detailed explanations and practice tests.',
    instructor: 'Rajesh Kumar',
    category: 'ssc',
    level: 'advanced',
    duration: '60 hours',
    rating: 4.9,
    ratingCount: 980,
    price: 3999,
    discountPrice: 2999,
    image: 'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500&q=80',
    featured: true,
    popular: true,
    lessons: 72,
    students: 2800,
    updatedAt: '2024-04-02',
    topics: ['Quantitative Aptitude', 'English Language', 'General Intelligence', 'General Awareness']
  },
  {
    id: '3',
    title: 'Science for Class 6-8 Students',
    description: 'Build strong science fundamentals with this interactive course designed specifically for middle school students.',
    instructor: 'Priya Patel',
    category: 'class-6-10',
    level: 'beginner',
    duration: '30 hours',
    rating: 4.7,
    ratingCount: 745,
    price: 1499,
    discountPrice: 1199,
    image: 'https://images.unsplash.com/photo-1532094349884-543bc11b234d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500&q=80',
    featured: false,
    popular: true,
    lessons: 35,
    students: 1950,
    updatedAt: '2024-01-10',
    topics: ['Physics', 'Chemistry', 'Biology', 'Environmental Science']
  },
  {
    id: '4',
    title: 'IBPS PO Complete Course',
    description: 'Comprehensive preparation for IBPS PO examination with sectional tests, mock interviews, and detailed study material.',
    instructor: 'Vikas Agarwal',
    category: 'banking',
    level: 'advanced',
    duration: '55 hours',
    rating: 4.8,
    ratingCount: 1120,
    price: 4499,
    discountPrice: 3499,
    image: 'https://images.unsplash.com/photo-1601597111158-2fceff292cdc?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500&q=80',
    featured: true,
    popular: false,
    lessons: 65,
    students: 2100,
    updatedAt: '2024-02-20',
    topics: ['Banking Awareness', 'Quantitative Aptitude', 'Reasoning', 'English Language', 'Computer Knowledge', 'Interview Preparation']
  },
  {
    id: '5',
    title: 'English Literature for Class 11 & 12',
    description: 'Master English literature with in-depth analysis of all CBSE prescribed texts, critical essays, and examination strategies.',
    instructor: 'Dr. Sarah Johnson',
    category: 'class-11-12',
    level: 'intermediate',
    duration: '45 hours',
    rating: 4.6,
    ratingCount: 820,
    price: 2799,
    discountPrice: 2299,
    image: 'https://images.unsplash.com/photo-1491841651911-c44c30c34548?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500&q=80',
    featured: false,
    popular: true,
    lessons: 50,
    students: 1750,
    updatedAt: '2024-03-05',
    topics: ['Prose', 'Poetry', 'Drama', 'Fiction', 'Literary Criticism']
  },
  {
    id: '6',
    title: 'RRB NTPC Complete Course',
    description: 'One-stop preparation course for Railway NTPC examination with bilingual content, speed tests, and sectional practice.',
    instructor: 'Amit Singh',
    category: 'railway',
    level: 'intermediate',
    duration: '50 hours',
    rating: 4.7,
    ratingCount: 930,
    price: 2999,
    discountPrice: 2499,
    image: 'https://images.unsplash.com/photo-1474487548417-781cb71495f3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500&q=80',
    featured: false,
    popular: false,
    lessons: 60,
    students: 2400,
    updatedAt: '2024-04-10',
    topics: ['General Awareness', 'Mathematics', 'General Intelligence', 'Reasoning']
  },
  {
    id: '7',
    title: 'Complete Physics for JEE Main & Advanced',
    description: 'Comprehensive physics course covering all topics for JEE Main and Advanced with solved examples and practice problems.',
    instructor: 'Prof. Ramesh Gupta',
    category: 'class-11-12',
    level: 'advanced',
    duration: '70 hours',
    rating: 4.9,
    ratingCount: 1560,
    price: 5999,
    discountPrice: 4999,
    image: 'https://images.unsplash.com/photo-1636466497217-26a8cbeaf0aa?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500&q=80',
    featured: true,
    popular: true,
    lessons: 80,
    students: 3500,
    updatedAt: '2024-03-20',
    topics: ['Mechanics', 'Thermodynamics', 'Electromagnetism', 'Optics', 'Modern Physics'],
    previewVideo: 'https://www.youtube.com/embed/TcMBFSGVi1c'
  },
  {
    id: '8',
    title: 'BPSC Prelims & Mains Complete Course',
    description: 'Structured preparation course for BPSC exam covering General Studies, Current Affairs, and Optional subjects.',
    instructor: 'Dr. Nikhil Jha',
    category: 'bpsc',
    level: 'advanced',
    duration: '80 hours',
    rating: 4.8,
    ratingCount: 890,
    price: 6499,
    discountPrice: 5499,
    image: 'https://images.unsplash.com/photo-1450101499163-c8848c66ca85?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500&q=80',
    featured: true,
    popular: false,
    lessons: 95,
    students: 1800,
    updatedAt: '2024-02-15',
    topics: ['Indian Polity', 'Geography', 'History', 'Economy', 'Current Affairs', 'Bihar Special']
  }
];

export const getFeaturedCourses = (): Course[] => {
  return courses.filter(course => course.featured);
};

export const getPopularCourses = (): Course[] => {
  return courses.filter(course => course.popular);
};

export const getCoursesByCategory = (category: string): Course[] => {
  return courses.filter(course => course.category === category);
};

export const getCourseById = (id: string): Course | undefined => {
  return courses.find(course => course.id === id);
};
